<?php

use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\MenuController;
use App\Http\Controllers\Admin\OrderController;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Admin\UserController;
use App\Http\Controllers\Admin\ReviewController;


/*
|--------------------------------------------------------------------------
| Halaman Awal
|--------------------------------------------------------------------------
*/
Route::get('/', fn () => view('welcome'));

/*
|--------------------------------------------------------------------------
| Redirect Setelah Login
|--------------------------------------------------------------------------
*/
Route::get('/redirect-after-login', function () {
    return match (Auth::user()->role) {
        'admin'     => redirect()->route('admin.dashboard'),
        'kurir'     => redirect()->route('kurir.dashboard'),
        'pelanggan' => redirect()->route('pelanggan.home'),
        default     => abort(403, 'Role tidak dikenali'),
    };
})->middleware('auth');

/*
|--------------------------------------------------------------------------
| Area Admin
|--------------------------------------------------------------------------
*/
Route::middleware(['auth', 'role_admin'])
    ->prefix('admin')
    ->name('admin.')
    ->group(function () {
        // Dashboard
        Route::get('/dashboard', [DashboardController::class, 'index'])
            ->name('dashboard');

        // Menu
        Route::resource('menu', MenuController::class);
        Route::resource('users', UserController::class);
        Route::resource('reviews', ReviewController::class)->only(['index', 'show']);
        
        
    });

/*
|--------------------------------------------------------------------------
| Area Kurir
|--------------------------------------------------------------------------
*/
Route::middleware(['auth', 'role_kurir'])
    ->prefix('kurir')
    ->name('kurir.')
    ->group(function () {
        Route::get('/dashboard', function () {
            return view('kurir.dashboard');
        })->name('dashboard');
    });

/*
|--------------------------------------------------------------------------
| Area Pelanggan
|--------------------------------------------------------------------------
*/
Route::middleware(['auth', 'role_pelanggan'])
    ->prefix('pelanggan')
    ->name('pelanggan.')
    ->group(function () {
        Route::get('/home', function () {
            return view('pelanggan.home');
        })->name('home');
    });
