<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use App\Models\User;

class UserSeeder extends Seeder
{
    public function run(): void
    {
        User::create([
            'name' => 'admin',
            'email' => 'afdhol@ganteng.com',
            'password' => Hash::make('admin123'),
            'role' => 'admin',
        ]);

        User::create([
            'name' => 'Kurir Dapur Afdhol',
            'email' => 'kurir@dapurafdhol.com',
            'password' => Hash::make('password123'),
            'role' => 'kurir',
        ]);

        User::create([
            'name' => 'Pelanggan Dapur Afdhol',
            'email' => 'pelanggan@dapurafdhol.com',
            'password' => Hash::make('password123'),
            'role' => 'pelanggan',
        ]);
    }
}
