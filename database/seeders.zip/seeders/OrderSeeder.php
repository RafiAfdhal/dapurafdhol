<?php
namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\User;
use App\Models\Menu;

class OrderSeeder extends Seeder
{
    public function run(): void
    {
        $user = User::factory()->create([
            'name' => 'Budi Santoso',
            'email' => 'budi@example.com',
            'password' => bcrypt('password'),
        ]);

        $menu1 = Menu::first();
        $menu2 = Menu::skip(1)->first();

        $order = Order::create([
            'user_id' => $user->id,
            'status' => 'Konfirmasi',
            'total' => 70000,
            'payment_method' => 'Cash',
            'customer_note' => 'Jangan pake bawang',
            'shipping_address' => 'Jl. Kenangan No. 123',
            'receiver_name' => 'Budi Santoso',
            'receiver_phone' => '08123456789',
        ]);

        OrderItem::create([
            'order_id' => $order->id,
            'menu_id' => $menu1->id,
            'quantity' => 2,
            'price' => $menu1->harga,
        ]);

        OrderItem::create([
            'order_id' => $order->id,
            'menu_id' => $menu2->id,
            'quantity' => 1,
            'price' => $menu2->harga,
        ]);
    }
}
