<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Menu;

class MenuSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        Menu::create([
            'nama' => 'Nasi Goreng Spesial',
            'kategori' => 'Makan Malam',
            'harga' => 25000,
            'stok' => 10,
            'gambar' => 'nasi_goreng.jpg',
        ]);

        Menu::create([
            'nama' => 'Mie Ayam Bakso',
            'kategori' => 'Makan Siang',
            'harga' => 20000,
            'stok' => 20,
            'gambar' => 'mie_ayam.jpg',
        ]);

        Menu::create([
            'nama' => 'Sate Ayam Madura',
            'kategori' => 'Makan Malam',
            'harga' => 30000,
            'stok' => 15,
            'gambar' => 'sate_ayam.jpg',
        ]);

        Menu::create([
            'nama' => 'Es Teh Manis',
            'kategori' => 'Minuman',
            'harga' => 5000,
            'stok' => 50,
            'gambar' => 'es_teh.jpg',
        ]);

        Menu::create([
            'nama' => 'Ayam Geprek Keju',
            'kategori' => 'Makan Siang',
            'harga' => 28000,
            'stok' => 12,
            'gambar' => 'ayam_geprek.jpg',
        ]);
    }
}
