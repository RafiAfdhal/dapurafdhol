<div class="sidebar" id="sidebar">
    <div class="sidebar-header">
        <h3>Dapur Afdhol Admin</h3>
    </div>
    <ul class="list-group sidebar-menu">
        <a href="{{ route('admin.dashboard') }}"
            class="list-group-item {{ request()->is('admin/dashboard') ? 'active' : '' }}">
            <i class="fas fa-tachometer-alt"></i> <span>Dashboard</span>
        </a>

        <a href="{{ route('admin.menu.index') }}"
            class="list-group-item {{ request()->is('admin/menu*') ? 'active' : '' }}">
            <i class="fas fa-utensils"></i> <span>Manajemen Menu</span>
        </a>

        <a href="#" class="list-group-item">
            <i class="fas fa-clipboard-list"></i> <span>Manajemen Pesanan</span>
        </a>
        <a href="{{ route('admin.users.index') }}"
            class="list-group-item {{ request()->is('admin/users*') ? 'active' : '' }}">
            <i class="fas fa-users"></i> <span>Manajemen Pengguna</span>
            <a href="#" class="list-group-item">
                <i class="fas fa-star"></i> <span>Ulasan Pelanggan</span>
            </a>
            <a href="#" class="list-group-item">
                <i class="fas fa-cogs"></i> <span>Pengaturan Sistem</span>
            </a>
            <form action="{{ route('logout') }}" method="POST">
    @csrf
    <button type="submit" class="list-group-item" style="border: none; background: transparent; width: 100%; text-align: left;">
        <i class="fas fa-sign-out-alt"></i> <span>Logout</span>
    </button>
</form>

    </ul>
</div>