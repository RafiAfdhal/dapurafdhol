<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Tambah Pengguna - Dapur Afdhol Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" />
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        /* Palet Warna Dapur Afdhol (Konsisten) */
        :root {
            --dark-brown: #3E2723;
            --medium-brown: #A1887F;
            --light-brown: #FBE9E7;
            --darkest-brown: #6D4C41;
            --orange-primary: #FFB300;
            --orange-hover: #FF8A00;
            --orange-darker: #E67A00;
            --white: #ffffff;
            --soft-gray: #f8f9fa;
            --red-delete: #dc3545;
            --green-active: #28a745;
            --blue-inactive: #007bff;
            --gray-blocked: #6c757d;
        }

        body {
            font-family: 'Poppins', sans-serif;
            color: var(--dark-brown);
            background-color: var(--light-brown);
            display: flex;
            min-height: 100vh;
            margin: 0;
            overflow-x: hidden;
        }

        h1, h2, h3, h4, h5, h6 {
            font-family: 'Playfair Display', serif;
            color: var(--dark-brown);
        }

        .btn-primary-custom {
            background-color: var(--orange-hover);
            border-color: var(--orange-hover);
            color: white;
            font-weight: 600;
            padding: 10px 20px;
            border-radius: 8px;
            transition: all 0.3s ease;
        }
        .btn-primary-custom:hover {
            background-color: var(--orange-darker);
            border-color: var(--orange-darker);
            transform: translateY(-1px);
            box-shadow: 0 3px 10px rgba(0,0,0,0.2);
        }
        .btn-outline-custom {
            border: 2px solid var(--orange-hover);
            color: var(--orange-hover);
            font-weight: 600;
            padding: 10px 20px;
            border-radius: 8px;
            transition: all 0.3s ease;
        }
        .btn-outline-custom:hover {
            background-color: var(--orange-hover);
            color: white;
            transform: translateY(-1px);
            box-shadow: 0 3px 10px rgba(0,0,0,0.2);
        }
        .btn-sm {
            padding: 6px 12px;
            font-size: 0.85rem;
        }

        .sidebar {
            width: 250px;
            min-width: 250px;
            background-color: var(--darkest-brown);
            color: var(--white);
            padding: 20px;
            box-shadow: 2px 0 10px rgba(0,0,0,0.2);
            position: fixed;
            height: 100%;
            overflow-y: auto;
            transition: all 0.3s ease;
            z-index: 1000;
        }
        .sidebar.collapsed { width: 80px; min-width: 80px; }
        .sidebar-header { text-align: center; margin-bottom: 30px; padding-bottom: 20px; border-bottom: 1px solid rgba(255, 255, 255, 0.1); }
        .sidebar-header h3 {
            color: var(--orange-primary); font-family: 'Playfair Display', serif; font-weight: 700; font-size: 1.8rem;
            white-space: nowrap; overflow: hidden; text-overflow: ellipsis; transition: opacity 0.3s ease;
        }
        .sidebar.collapsed .sidebar-header h3 { opacity: 0; width: 0; padding: 0; margin: 0; height: 0; }
        .sidebar-menu .list-group-item {
            background-color: transparent; color: var(--light-brown); border: none; padding: 12px 15px;
            font-weight: 500; border-radius: 5px; margin-bottom: 5px; transition: all 0.3s ease;
            display: flex; align-items: center; text-decoration: none;
        }
        .sidebar-menu .list-group-item i {
            font-size: 1.2rem; margin-right: 15px; transition: margin 0.3s ease; min-width: 25px; text-align: center;
        }
        .sidebar.collapsed .sidebar-menu .list-group-item i { margin-right: 0; }
        .sidebar-menu .list-group-item span {
            white-space: nowrap; overflow: hidden; text-overflow: ellipsis; transition: opacity 0.3s ease;
        }
        .sidebar.collapsed .sidebar-menu .list-group-item span { opacity: 0; width: 0; display: none; }
        .sidebar-menu .list-group-item:hover,
        .sidebar-menu .list-group-item.active { background-color: rgba(255, 179, 0, 0.2); color: var(--orange-primary); }
        .sidebar-menu .list-group-item.active { font-weight: 600; }

        .main-content {
            flex-grow: 1;
            margin-left: 250px;
            transition: margin-left 0.3s ease;
            padding-top: 75px;
            position: relative;
        }
        .main-content.expanded { margin-left: 80px; }

        .admin-navbar {
            background-color: var(--white);
            padding: 15px 25px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            position: fixed;
            width: calc(100% - 250px);
            top: 0;
            left: 250px;
            z-index: 999;
            transition: width 0.3s ease, left 0.3s ease;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .admin-navbar.expanded {
            width: calc(100% - 80px);
            left: 80px;
        }
        .admin-navbar .nav-link {
            color: var(--dark-brown); margin-left: 15px; font-size: 1.1rem; transition: color 0.3s ease;
        }
        .admin-navbar .nav-link:hover { color: var(--orange-primary); }
        .admin-navbar .toggle-btn {
            background: transparent; border: none; font-size: 1.5rem; color: var(--dark-brown); cursor: pointer;
        }
        .admin-panel-title {
            position: absolute;
            left: 50%;
            transform: translateX(-50%);
            white-space: nowrap;
        }

        .content-padding { padding: 25px; }

        .admin-card {
            background-color: var(--white);
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
            padding: 25px;
            margin-bottom: 25px;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }
        .admin-card:hover { transform: translateY(-3px); box-shadow: 0 6px 20px rgba(0,0,0,0.12); }
        .admin-card-header {
            border-bottom: 1px solid var(--light-brown);
            padding-bottom: 15px; margin-bottom: 20px;
            color: var(--dark-brown); font-size: 1.5rem; font-family: 'Playfair Display', serif; font-weight: 700;
        }
        .form-control-filter {
            border-radius: 8px;
            border: 1px solid var(--medium-brown);
            padding: 8px 12px;
            color: var(--dark-brown);
            background-color: var(--white);
        }
        .form-control-filter:focus {
            border-color: var(--orange-primary);
            box-shadow: 0 0 0 0.25rem rgba(255, 179, 0, 0.25);
        }

        @media (max-width: 992px) {
            .sidebar { width: 80px; min-width: 80px; }
            .sidebar-header h3 { opacity: 0; width: 0; padding: 0; margin: 0; height: 0; }
            .sidebar-menu .list-group-item span { opacity: 0; width: 0; display: none; }
            .sidebar-menu .list-group-item i { margin-right: 0; }
            .main-content { margin-left: 80px; padding-top: 75px; }
            .admin-navbar { width: calc(100% - 80px); left: 80px; }
            .sidebar-toggle-btn { display: none; }
        }
        @media (max-width: 768px) {
            .sidebar { position: fixed; left: -250px; box-shadow: none; z-index: 1000; width: 250px; min-width: 250px; }
            .sidebar.show { left: 0; box-shadow: 2px 0 10px rgba(0,0,0,0.2); }
            .sidebar.collapsed .sidebar-header h3,
            .sidebar.collapsed .sidebar-menu .list-group-item span { opacity: 1; width: auto; display: inline-block; }
            .sidebar.collapsed .sidebar-menu .list-group-item i { margin-right: 15px; }
            .main-content { margin-left: 0; width: 100%; padding-top: 75px; }
            .admin-navbar { width: 100%; left: 0; }
            .sidebar-toggle-btn { display: block; }
            .admin-panel-title { font-size: 1.2rem; position: static; transform: none; flex-grow: 1; text-align: center; }
        }
    </style>
</head>
<body>

    <div class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <h3>Dapur Afdhol Admin</h3>
        </div>
        <ul class="list-group sidebar-menu">
            <a href="{{ route('admin.dashboard') }}" class="list-group-item">
                <i class="fas fa-tachometer-alt"></i> <span>Dashboard</span>
            </a>
            <a href="{{ route('admin.menu.index') }}" class="list-group-item">
                <i class="fas fa-utensils"></i> <span>Manajemen Menu</span>
            </a>
            <a href="#" class="list-group-item">
                <i class="fas fa-clipboard-list"></i> <span>Manajemen Pesanan</span>
            </a>
            <a href="{{ route('admin.users.index') }}" class="list-group-item active">
                <i class="fas fa-users"></i> <span>Manajemen Pengguna</span>
            </a>
            <a href="#" class="list-group-item">
                <i class="fas fa-star"></i> <span>Ulasan Pelanggan</span>
            </a>
            <a href="#" class="list-group-item">
                <i class="fas fa-cogs"></i> <span>Pengaturan Sistem</span>
            </a>
            <hr class="text-white-50">
            <a href="#" class="list-group-item" id="logout-btn">
                <i class="fas fa-sign-out-alt"></i> <span>Logout</span>
            </a>
        </ul>
    </div>

    <div class="main-content" id="main-content">
        <nav class="admin-navbar" id="admin-navbar">
            <button class="toggle-btn" id="sidebar-toggle"><i class="fas fa-bars"></i></button>
            <h4 class="m-0 admin-panel-title">Tambah Pengguna</h4>
            <div class="d-flex align-items-center">
                <a href="#" class="nav-link"><i class="fas fa-bell"></i><span class="badge bg-danger ms-1">3</span></a>
                <a href="#" class="nav-link"><i class="fas fa-envelope"></i><span class="badge bg-info ms-1">5</span></a>
                <a href="#" class="nav-link"><i class="fas fa-user-circle"></i> Admin</a>
            </div>
        </nav>

        <div class="content-padding">
            <h1 class="mb-4">Tambah Pengguna Baru</h1>
            
            <div class="admin-card">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h5 class="admin-card-header mb-0" style="border-bottom: none;">Formulir Pengguna</h5>
                    <a href="{{ route('admin.users.index') }}" class="btn btn-outline-custom">
                        <i class="fas fa-arrow-left me-1"></i> Kembali
                    </a>
                </div>

                <form id="userForm" method="POST" action="{{ route('admin.users.store') }}">
                    @csrf
                    <div class="mb-3">
                        <label for="userName" class="form-label">Nama Lengkap</label>
                        <input type="text" class="form-control form-control-filter" id="userName" name="name" required>
                    </div>
                    <div class="mb-3">
                        <label for="userEmail" class="form-label">Email</label>
                        <input type="email" class="form-control form-control-filter" id="userEmail" name="email" required>
                    </div>
                    <div class="mb-3">
                        <label for="userRole" class="form-label">Peran</label>
                        <select class="form-select form-control-filter" id="userRole" name="role" required>
                            <option value="pelanggan">Pelanggan</option>
                            <option value="kurir">Kurir</option>
                            <option value="admin">Admin</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="userPassword" class="form-label">Password</label>
                        <input type="password" class="form-control form-control-filter" id="userPassword" name="password" required>
                    </div>
                    <button type="submit" class="btn btn-primary-custom mt-3">Simpan Pengguna</button>
                </form>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const sidebar = document.getElementById('sidebar');
            const mainContent = document.getElementById('main-content');
            const adminNavbar = document.getElementById('admin-navbar');
            const sidebarToggle = document.getElementById('sidebar-toggle');

            function updateLayout() {
                const isCollapsed = sidebar.classList.contains('collapsed');
                if (window.innerWidth <= 768) {
                    sidebar.classList.remove('collapsed');
                    mainContent.classList.remove('expanded');
                    adminNavbar.classList.remove('expanded');
                    sidebar.style.left = sidebar.classList.contains('show') ? '0' : '-250px';
                    mainContent.style.marginLeft = '0';
                    adminNavbar.style.left = '0';
                    adminNavbar.style.width = '100%';
                } else if (window.innerWidth <= 992) {
                    sidebar.classList.add('collapsed');
                    mainContent.classList.add('expanded');
                    adminNavbar.classList.add('expanded');
                    sidebar.style.left = '0';
                    mainContent.style.marginLeft = '80px';
                    adminNavbar.style.left = '80px';
                    adminNavbar.style.width = 'calc(100% - 80px)';
                } else {
                    if (isCollapsed) {
                        mainContent.classList.add('expanded');
                        adminNavbar.classList.add('expanded');
                        sidebar.style.left = '0';
                        mainContent.style.marginLeft = '80px';
                        adminNavbar.style.left = '80px';
                        adminNavbar.style.width = 'calc(100% - 80px)';
                    } else {
                        mainContent.classList.remove('expanded');
                        adminNavbar.classList.remove('expanded');
                        sidebar.style.left = '0';
                        mainContent.style.marginLeft = '250px';
                        adminNavbar.style.left = '250px';
                        adminNavbar.style.width = 'calc(100% - 250px)';
                    }
                }
            }

            updateLayout();
            if (sidebarToggle) {
                sidebarToggle.addEventListener('click', function() {
                    if (window.innerWidth <= 768) {
                        sidebar.classList.toggle('show');
                        updateLayout();
                    } else {
                        sidebar.classList.toggle('collapsed');
                        updateLayout();
                    }
                });
            }
            window.addEventListener('resize', function() {
                if (window.innerWidth > 768) {
                    sidebar.classList.remove('show');
                }
                updateLayout();
            });

            // Ganti rute aktif untuk navigasi jika diperlukan
            // const userCreateRoute = '{{ route('admin.users.create') }}';
            // const sidebarLinks = document.querySelectorAll('.sidebar-menu .list-group-item');
            // sidebarLinks.forEach(link => {
            //     link.classList.remove('active');
            //     if (link.getAttribute('href') === userCreateRoute) {
            //         link.classList.add('active');
            //     }
            // });

            document.getElementById('logout-btn').addEventListener('click', function(e) {
                e.preventDefault();
                if (confirm('Apakah Anda yakin ingin logout?')) {
                    window.location.href = '#';
                }
            });
        });
    </script>
</body>
</html>
