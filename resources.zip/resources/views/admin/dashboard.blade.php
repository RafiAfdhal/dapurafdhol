@extends('layouts.admin.master')

@section('title', 'Dashboard Admin')

@section('content')
    <h1 class="mb-4">Dashboard Admin</h1>

    {{-- Card Statistik --}}
    <div class="row g-4 mb-4">
        <div class="col-md-4">
            <div class="admin-card text-center">
                <i class="fas fa-money-bill-wave fa-3x text-success mb-3"></i>
                <h5 class="admin-card-header">Total Penjualan</h5>
                <div class="card-value">Rp 12.500.000</div>
                <p class="card-text-muted">Bulan ini</p>
            </div>
        </div>
        <div class="col-md-4">
            <div class="admin-card text-center">
                <i class="fas fa-receipt fa-3x text-info mb-3"></i>
                <h5 class="admin-card-header">Pesanan Baru</h5>
                <div class="card-value">45</div>
                <p class="card-text-muted">Hari ini</p>
            </div>
        </div>
        <div class="col-md-4">
            <div class="admin-card text-center">
                <i class="fas fa-users fa-3x text-primary mb-3"></i>
                <h5 class="admin-card-header">Pelanggan Baru</h5>
                <div class="card-value">12</div>
                <p class="card-text-muted">Minggu ini</p>
            </div>
        </div>
    </div>

    {{-- Pesanan Terbaru --}}
    <div class="admin-card mb-4">
        <h5 class="admin-card-header">Pesanan Terbaru</h5>
        <div class="table-responsive">
            <table class="table table-hover table-custom">
                <thead>
                    <tr>
                        <th>ID Pesanan</th>
                        <th>Pelanggan</th>
                        <th>Tanggal</th>
                        <th>Total</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>#ORD001</td>
                        <td>Budi Santoso</td>
                        <td>15/07/2025</td>
                        <td>Rp 75.000</td>
                        <td><span class="status-badge pending">Pending</span></td>
                        <td><button class="btn btn-sm btn-primary-custom">Detail</button></td>
                    </tr>
                    <tr>
                        <td>#ORD002</td>
                        <td>Citra Dewi</td>
                        <td>14/07/2025</td>
                        <td>Rp 120.000</td>
                        <td><span class="status-badge success">Selesai</span></td>
                        <td><button class="btn btn-sm btn-primary-custom">Detail</button></td>
                    </tr>
                    <tr>
                        <td>#ORD003</td>
                        <td>Agus Salim</td>
                        <td>14/07/2025</td>
                        <td>Rp 45.000</td>
                        <td><span class="status-badge cancelled">Dibatalkan</span></td>
                        <td><button class="btn btn-sm btn-primary-custom">Detail</button></td>
                    </tr>
                    <tr>
                        <td>#ORD004</td>
                        <td>Dewi Sartika</td>
                        <td>13/07/2025</td>
                        <td>Rp 90.000</td>
                        <td><span class="status-badge success">Selesai</span></td>
                        <td><button class="btn btn-sm btn-primary-custom">Detail</button></td>
                    </tr>
                    <tr>
                        <td>#ORD005</td>
                        <td>Dewi Sartika</td>
                        <td>13/07/2025</td>
                        <td>Rp 90.000</td>
                        <td><span class="status-badge pending">Pengiriman</span></td>
                        <td><button class="btn btn-sm btn-primary-custom">Detail</button></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
@endsection
