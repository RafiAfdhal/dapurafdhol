   <style>
        /* Palet Warna Dapur Afdhol (Konsisten dengan file pelanggan):
         * Cokelat Gelap (sidebar admin, footer, background overlay): #6D4C41 (RGBA: 109, 76, 65)
         * Oranye/Kuning (aksen, button): #FFB300
         * Oranye Cerah (button hover): #FF8A00
         * Oranye Gelap (button hover darker): #E67A00
         * Krem (card background, body background): #FBE9E7
         * Teks Utama: #3E2723 (Dark Brown)
         * Teks Sekunder/Placeholder: #A1887F (Medium Brown)
         */

        :root {
            --dark-brown: #3E2723;
            --medium-brown: #A1887F;
            --light-brown: #FBE9E7; /* Krem */
            --darkest-brown: #6D4C41; /* Cokelat Gelap */
            --orange-primary: #FFB300;
            --orange-hover: #FF8A00;
            --orange-darker: #E67A00;
            --white: #ffffff;
            --soft-gray: #f8f9fa; /* Untuk background card yang lebih ringan */
        }

        body {
            font-family: 'Poppins', sans-serif;
            color: var(--dark-brown);
            background-color: var(--light-brown); /* Latar belakang utama krem */
            display: flex; /* Untuk layout sidebar dan konten */
            min-height: 100vh;
            margin: 0;
            overflow-x: hidden;
        }

        h1, h2, h3, h4, h5, h6 {
            font-family: 'Playfair Display', serif;
            color: var(--dark-brown);
        }

        /* --- Global Button Styles (Konsisten dengan pelanggan) --- */
        .btn-primary-custom {
            background-color: var(--orange-hover);
            border-color: var(--orange-hover);
            color: white;
            font-weight: 600;
            padding: 10px 20px;
            border-radius: 8px;
            transition: all 0.3s ease;
        }
        .btn-primary-custom:hover {
            background-color: var(--orange-darker);
            border-color: var(--orange-darker);
            transform: translateY(-1px);
            box-shadow: 0 3px 10px rgba(0,0,0,0.2);
        }
        .btn-outline-custom {
            border: 2px solid var(--orange-hover);
            color: var(--orange-hover);
            font-weight: 600;
            padding: 10px 20px;
            border-radius: 8px;
            transition: all 0.3s ease;
        }
        .btn-outline-custom:hover {
            background-color: var(--orange-hover);
            color: white;
            transform: translateY(-1px);
            box-shadow: 0 3px 10px rgba(0,0,0,0.2);
        }
        .btn-sm {
            padding: 6px 12px;
            font-size: 0.85rem;
        }

        /* --- Sidebar Styles --- */
        .sidebar {
            width: 250px;
            min-width: 250px;
            background-color: var(--darkest-brown); /* Cokelat Gelap */
            color: var(--white);
            padding: 20px;
            box-shadow: 2px 0 10px rgba(0,0,0,0.2);
            position: fixed;
            height: 100%;
            overflow-y: auto;
            transition: all 0.3s ease;
            z-index: 1000;
        }
        .sidebar.collapsed {
            width: 80px;
            min-width: 80px;
        }
        .sidebar-header {
            text-align: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        .sidebar-header h3 {
            color: var(--orange-primary);
            font-family: 'Playfair Display', serif;
            font-weight: 700;
            font-size: 1.8rem;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            transition: opacity 0.3s ease;
        }
        .sidebar.collapsed .sidebar-header h3 {
            opacity: 0;
            width: 0;
            padding: 0;
            margin: 0;
            height: 0;
        }
        .sidebar-menu .list-group-item {
            background-color: transparent;
            color: var(--light-brown);
            border: none;
            padding: 12px 15px;
            font-weight: 500;
            border-radius: 5px;
            margin-bottom: 5px;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            text-decoration: none;
        }
        .sidebar-menu .list-group-item i {
            font-size: 1.2rem;
            margin-right: 15px;
            transition: margin 0.3s ease;
            min-width: 25px; /* Ensure icon has space even when text is hidden */
            text-align: center;
        }
        .sidebar.collapsed .sidebar-menu .list-group-item i {
            margin-right: 0;
        }
        .sidebar-menu .list-group-item span {
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            transition: opacity 0.3s ease;
        }
        .sidebar.collapsed .sidebar-menu .list-group-item span {
            opacity: 0;
            width: 0;
            display: none; /* Hide the text completely */
        }
        .sidebar-menu .list-group-item:hover,
        .sidebar-menu .list-group-item.active {
            background-color: rgba(255, 179, 0, 0.2); /* Orange primary with transparency */
            color: var(--orange-primary);
        }
        .sidebar-menu .list-group-item.active {
            font-weight: 600;
        }

        /* --- Main Content Area --- */
        .main-content {
            flex-grow: 1;
            margin-left: 250px; /* Lebar sidebar */
            transition: margin-left 0.3s ease;
            padding-top: 70px; /* Ruang untuk navbar fixed */
        }
        .main-content.expanded {
            margin-left: 80px; /* Lebar sidebar saat collapsed */
        }

        /* --- Top Navbar Admin --- */
        .admin-navbar {
            background-color: var(--white);
            padding: 15px 25px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            position: fixed;
            width: calc(100% - 250px); /* Sesuaikan dengan lebar sidebar */
            top: 0;
            right: 0;
            z-index: 999;
            transition: width 0.3s ease, left 0.3s ease;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .admin-navbar.expanded {
            width: calc(100% - 80px); /* Sesuaikan saat sidebar collapsed */
            left: 80px; /* Pindah ke kanan sesuai sidebar collapsed */
        }
        .admin-navbar .navbar-brand-custom { /* Untuk judul di top navbar jika ada */
            color: var(--darkest-brown) !important;
            font-family: 'Playfair Display', serif;
            font-size: 1.5rem;
            font-weight: 700;
        }
        .admin-navbar .nav-link {
            color: var(--dark-brown);
            margin-left: 15px;
            font-size: 1.1rem;
            transition: color 0.3s ease;
        }
        .admin-navbar .nav-link:hover {
            color: var(--orange-primary);
        }
        .admin-navbar .toggle-btn {
            background: transparent;
            border: none;
            font-size: 1.5rem;
            color: var(--dark-brown);
            cursor: pointer;
        }

        /* --- Content Padding --- */
        .content-padding {
            padding: 25px;
        }

        /* --- Admin Card Styles (Konsisten dengan pelanggan) --- */
        .admin-card {
            background-color: var(--white);
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
            padding: 25px;
            margin-bottom: 25px;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }
        .admin-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 20px rgba(0,0,0,0.12);
        }
        .admin-card-header {
            border-bottom: 1px solid var(--light-brown);
            padding-bottom: 15px;
            margin-bottom: 20px;
            color: var(--dark-brown);
            font-size: 1.5rem;
            font-family: 'Playfair Display', serif;
            font-weight: 700;
        }
        .admin-card .card-value {
            font-size: 2.5rem;
            font-weight: 700;
            color: var(--orange-primary);
            margin-top: 10px;
        }
        .admin-card .card-text-muted {
            color: var(--medium-brown);
            font-size: 0.9em;
        }

        /* --- Table Styles --- */
        .table-custom thead {
            background-color: var(--darkest-brown);
            color: var(--white);
        }
        .table-custom thead th {
            border-bottom: none;
            padding: 12px 15px;
            font-weight: 600;
        }
        .table-custom tbody tr {
            background-color: var(--white);
            border-bottom: 1px solid var(--light-brown);
        }
        .table-custom tbody tr:last-child {
            border-bottom: none;
        }
        .table-custom tbody td {
            padding: 12px 15px;
            vertical-align: middle;
        }
        .table-custom .status-badge {
            padding: 5px 10px;
            border-radius: 5px;
            font-size: 0.85em;
            font-weight: 600;
        }
        .status-badge.success { background-color: #d4edda; color: #155724; } /* Bootstrap green light */
        .status-badge.pending { background-color: #fff3cd; color: #856404; } /* Bootstrap yellow light */
        .status-badge.cancelled { background-color: #f8d7da; color: #721c24; } /* Bootstrap red light */

        /* --- Form Styles --- */
        .form-control-custom {
            border-radius: 8px;
            border: 1px solid var(--medium-brown);
            padding: 10px 15px;
            color: var(--dark-brown);
            background-color: var(--light-brown);
        }
        .form-control-custom:focus {
            border-color: var(--orange-primary);
            box-shadow: 0 0 0 0.25rem rgba(255, 179, 0, 0.25);
            background-color: var(--white);
        }
        .form-label-custom {
            font-weight: 500;
            color: var(--dark-brown);
            margin-bottom: 8px;
        }
        .input-group-text-custom {
            background-color: var(--orange-primary);
            border: 1px solid var(--orange-primary);
            color: var(--white);
            border-radius: 8px 0 0 8px;
        }

        /* Responsive Adjustments */
        @media (max-width: 992px) {
            .sidebar {
                width: 80px;
                min-width: 80px;
            }
            .sidebar-header h3 {
                opacity: 0;
                width: 0;
                padding: 0;
                margin: 0;
                height: 0;
            }
            .sidebar-menu .list-group-item span {
                opacity: 0;
                width: 0;
                display: none;
            }
            .sidebar-menu .list-group-item i {
                margin-right: 0;
            }
            .main-content {
                margin-left: 80px;
            }
            .admin-navbar {
                width: calc(100% - 80px);
                left: 80px;
            }
            .sidebar-toggle-btn {
                display: none; /* Hide toggle button on smaller screens as sidebar is always collapsed */
            }
        }
         @media (max-width: 768px) {
            .sidebar {
                position: absolute; /* Change to absolute for better mobile experience */
                left: -250px; /* Hide by default */
                box-shadow: none; /* Remove shadow when hidden */
                z-index: 1000;
            }
            .sidebar.show {
                left: 0; /* Show when toggled */
                box-shadow: 2px 0 10px rgba(0,0,0,0.2);
            }
            .main-content {
                margin-left: 0; /* No margin on mobile */
                width: 100%;
            }
            .admin-navbar {
                width: 100%;
                left: 0;
            }
            .sidebar-toggle-btn {
                display: block; /* Show toggle button on mobile */
            }
        }
    </style>