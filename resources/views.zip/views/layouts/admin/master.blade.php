{{-- Master Layout untuk Admin --}}
<!DOCTYPE html>
<html lang="id">
<head>
    @include('layouts.admin.head')
    @include('layouts.admin.style')
</head>
<body>

    {{-- Sidebar --}}
    @include('layouts.admin.sidebar')

    {{-- Main Content --}}
    <div class="main-content" id="main-content">
        {{-- Top Navbar --}}
        <nav class="admin-navbar" id="admin-navbar">
            <button class="toggle-btn" id="sidebar-toggle"><i class="fas fa-bars"></i></button>
            <h4 class="m-0 admin-panel-title d-none d-md-block">@yield('title', 'Dashboard')</h4>
            <div class="d-flex align-items-center">
                <a href="#" class="nav-link"><i class="fas fa-bell"></i><span class="badge bg-danger ms-1">3</span></a>
                <a href="#" class="nav-link"><i class="fas fa-envelope"></i><span class="badge bg-info ms-1">5</span></a>
                <a href="#" class="nav-link"><i class="fas fa-user-circle"></i> {{ auth()->user()->name }}</a>
            </div>
        </nav>

        {{-- Konten Halaman --}}
        <div class="content-padding">
            @yield('content')
        </div>
    </div>

    @include('layouts.admin.script')
</body>
</html>
