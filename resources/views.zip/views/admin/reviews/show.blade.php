<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Ulasan - Dapur Afdhol Admin</title>

    <!-- Bootstrap & Icon -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"/>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"/>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <style>
        :root {
            --dark-brown: #3E2723;
            --medium-brown: #A1887F;
            --light-brown: #FBE9E7;
            --darkest-brown: #6D4C41;
            --orange-primary: #FFB300;
            --orange-hover: #FF8A00;
            --orange-darker: #E67A00;
            --white: #ffffff;
            --red-delete: #dc3545;
        }
        body {
            font-family: 'Poppins', sans-serif;
            background-color: var(--light-brown);
            color: var(--dark-brown);
            display: flex;
            margin: 0;
        }
        .sidebar {
            width: 250px;
            min-width: 250px;
            background-color: var(--darkest-brown);
            color: var(--white);
            padding: 20px;
            position: fixed;
            height: 100%;
        }
        .sidebar-header h3 {
            color: var(--orange-primary);
            font-family: 'Playfair Display', serif;
            font-weight: 700;
        }
        .sidebar-menu .list-group-item {
            background: transparent;
            color: var(--light-brown);
            border: none;
            padding: 12px 15px;
            font-weight: 500;
        }
        .sidebar-menu .list-group-item.active {
            background-color: rgba(255, 179, 0, 0.2);
            color: var(--orange-primary);
            font-weight: 600;
        }
        .main-content {
            flex-grow: 1;
            margin-left: 250px;
            padding-top: 75px;
        }
        .admin-navbar {
            background-color: var(--white);
            padding: 15px 25px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            position: fixed;
            top: 0;
            left: 250px;
            width: calc(100% - 250px);
            z-index: 999;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .content-padding { padding: 25px; }
        .product-detail-section {
            background-color: var(--white);
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
            padding: 25px;
            margin-bottom: 30px;
            display: flex;
            align-items: flex-start;
            gap: 25px;
        }
        .product-image {
            width: 150px;
            height: 150px;
            object-fit: cover;
            border-radius: 8px;
        }
        .customer-reviews-section {
            background-color: var(--white);
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
            padding: 25px;
        }
        .review-item {
            border-bottom: 1px solid var(--light-brown);
            padding: 20px 0;
        }
        .review-item:last-child { border-bottom: none; }
        .btn-delete {
            background-color: var(--red-delete);
            border: none;
            padding: 8px 15px;
            border-radius: 8px;
            color: #fff;
            font-weight: 600;
        }
        .btn-delete:hover { background-color: #c82333; }
        .btn-outline-custom {
            border: 2px solid var(--orange-hover);
            color: var(--orange-hover);
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: 600;
        }
        .btn-outline-custom:hover {
            background-color: var(--orange-hover);
            color: #fff;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h3>Dapur Afdhol Admin</h3>
        </div>
        <ul class="list-group sidebar-menu">
            <a href="{{ route('admin.dashboard') }}" class="list-group-item">
                <i class="fas fa-tachometer-alt"></i> <span>Dashboard</span>
            </a>
            <a href="{{ route('admin.menus.index') }}" class="list-group-item">
                <i class="fas fa-utensils"></i> <span>Manajemen Menu</span>
            </a>
            <a href="{{ route('admin.orders.index') }}" class="list-group-item">
                <i class="fas fa-clipboard-list"></i> <span>Manajemen Pesanan</span>
            </a>
            <a href="{{ route('admin.users.index') }}" class="list-group-item">
                <i class="fas fa-users"></i> <span>Manajemen Pengguna</span>
            </a>
            <a href="{{ route('admin.reviews.index') }}" class="list-group-item active">
                <i class="fas fa-star"></i> <span>Ulasan Pelanggan</span>
            </a>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <nav class="admin-navbar">
            <h4 class="m-0">Detail Ulasan</h4>
            <div><i class="fas fa-user-circle"></i> Admin</div>
        </nav>

        <div class="content-padding">
            <!-- Detail Produk -->
            <div class="product-detail-section">
                <img src="{{ asset('storage/' . $review->menu->gambar) }}" 
                     alt="{{ $review->menu->nama }}" 
                     class="product-image">
                <div class="product-info">
                    <h2>{{ $review->menu->nama }}</h2>
                    <div class="rating-summary">
                        <span class="avg-rating">{{ $review->rating }}</span>
                        <div class="star-rating">
                            @for ($i = 1; $i <= 5; $i++)
                                <i class="fa-star {{ $i <= $review->rating ? 'fas text-warning' : 'far text-muted' }}"></i>
                            @endfor
                        </div>
                    </div>
                </div>
            </div>

            <!-- Ulasan -->
            <div class="customer-reviews-section">
                <h5>Ulasan Pelanggan</h5>
                <div class="review-item">
                    <div class="review-header d-flex justify-content-between">
                        <span class="customer-name">{{ $review->user->name }}</span>
                        <span class="review-date">{{ $review->created_at->format('d M Y') }}</span>
                    </div>
                    <div class="review-rating mb-2">
                        @for ($i = 1; $i <= 5; $i++)
                            <i class="fa-star {{ $i <= $review->rating ? 'fas text-warning' : 'far text-muted' }}"></i>
                        @endfor
                    </div>
                    <p class="review-text">{{ $review->review_text }}</p>
                    <form action="{{ route('admin.reviews.destroy', $review->id) }}" method="POST" onsubmit="return confirm('Yakin hapus ulasan ini?')">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-delete">
                            <i class="fas fa-trash-alt"></i> Hapus
                        </button>
                    </form>
                </div>
            </div>

            <!-- Back Button -->
            <div class="text-center mt-4">
                <a href="{{ route('admin.reviews.index') }}" class="btn btn-outline-custom">
                    <i class="fas fa-arrow-left"></i> Kembali ke Daftar Ulasan
                </a>
            </div>
        </div>
    </div>
</body>
</html>
