<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Ulasan Pelanggan - Dapur Afdhol Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" />
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

   <style>
        /* Palet Warna Dapur Afdhol (Konsisten) */
        :root {
            --dark-brown: #3E2723;
            --medium-brown: #A1887F;
            --light-brown: #FBE9E7;
            --darkest-brown: #6D4C41;
            --orange-primary: #FFB300;
            --orange-hover: #FF8A00;
            --orange-darker: #E67A00;
            --white: #ffffff;
            --soft-gray: #f8f9fa;
            --red-delete: #dc3545;
            --green-active: #28a745;
            --blue-inactive: #007bff;
            --gray-blocked: #6c757d;
        }

        body {
            font-family: 'Poppins', sans-serif;
            color: var(--dark-brown);
            background-color: var(--light-brown);
            display: flex;
            min-height: 100vh;
            margin: 0;
            overflow-x: hidden;
        }

        h1, h2, h3, h4, h5, h6 {
            font-family: 'Playfair Display', serif;
            color: var(--dark-brown);
        }

        .btn-primary-custom {
            background-color: var(--orange-hover);
            border-color: var(--orange-hover);
            color: white;
            font-weight: 600;
            padding: 10px 20px;
            border-radius: 8px;
            transition: all 0.3s ease;
        }
        .btn-primary-custom:hover {
            background-color: var(--orange-darker);
            border-color: var(--orange-darker);
            transform: translateY(-1px);
            box-shadow: 0 3px 10px rgba(0,0,0,0.2);
        }
        .btn-outline-custom {
            border: 2px solid var(--orange-hover);
            color: var(--orange-hover);
            font-weight: 600;
            padding: 10px 20px;
            border-radius: 8px;
            transition: all 0.3s ease;
        }
        .btn-outline-custom:hover {
            background-color: var(--orange-hover);
            color: white;
            transform: translateY(-1px);
            box-shadow: 0 3px 10px rgba(0,0,0,0.2);
        }
        .btn-sm {
            padding: 6px 12px;
            font-size: 0.85rem;
        }

        .sidebar {
            width: 250px;
            min-width: 250px;
            background-color: var(--darkest-brown);
            color: var(--white);
            padding: 20px;
            box-shadow: 2px 0 10px rgba(0,0,0,0.2);
            position: fixed;
            height: 100%;
            overflow-y: auto;
            transition: all 0.3s ease;
            z-index: 1000;
        }
        .sidebar.collapsed { width: 80px; min-width: 80px; }
        .sidebar-header { text-align: center; margin-bottom: 30px; padding-bottom: 20px; border-bottom: 1px solid rgba(255, 255, 255, 0.1); }
        .sidebar-header h3 {
            color: var(--orange-primary); font-family: 'Playfair Display', serif; font-weight: 700; font-size: 1.8rem;
            white-space: nowrap; overflow: hidden; text-overflow: ellipsis; transition: opacity 0.3s ease;
        }
        .sidebar.collapsed .sidebar-header h3 { opacity: 0; width: 0; padding: 0; margin: 0; height: 0; }
        .sidebar-menu .list-group-item {
            background-color: transparent; color: var(--light-brown); border: none; padding: 12px 15px;
            font-weight: 500; border-radius: 5px; margin-bottom: 5px; transition: all 0.3s ease;
            display: flex; align-items: center; text-decoration: none;
        }
        .sidebar-menu .list-group-item i {
            font-size: 1.2rem; margin-right: 15px; transition: margin 0.3s ease; min-width: 25px; text-align: center;
        }
        .sidebar.collapsed .sidebar-menu .list-group-item i { margin-right: 0; }
        .sidebar-menu .list-group-item span {
            white-space: nowrap; overflow: hidden; text-overflow: ellipsis; transition: opacity 0.3s ease;
        }
        .sidebar.collapsed .sidebar-menu .list-group-item span { opacity: 0; width: 0; display: none; }
        .sidebar-menu .list-group-item:hover,
        .sidebar-menu .list-group-item.active { background-color: rgba(255, 179, 0, 0.2); color: var(--orange-primary); }
        .sidebar-menu .list-group-item.active { font-weight: 600; }

        .main-content {
            flex-grow: 1;
            margin-left: 250px;
            transition: margin-left 0.3s ease;
            padding-top: 75px;
            position: relative;
        }
        .main-content.expanded { margin-left: 80px; }

        .admin-navbar {
            background-color: var(--white);
            padding: 15px 25px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            position: fixed;
            width: calc(100% - 250px);
            top: 0;
            left: 250px;
            z-index: 999;
            transition: width 0.3s ease, left 0.3s ease;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .admin-navbar.expanded {
            width: calc(100% - 80px);
            left: 80px;
        }
        .admin-navbar .nav-link {
            color: var(--dark-brown); margin-left: 15px; font-size: 1.1rem; transition: color 0.3s ease;
        }
        .admin-navbar .nav-link:hover { color: var(--orange-primary); }
        .admin-navbar .toggle-btn {
            background: transparent; border: none; font-size: 1.5rem; color: var(--dark-brown); cursor: pointer;
        }
        .admin-panel-title {
            position: absolute;
            left: 50%;
            transform: translateX(-50%);
            white-space: nowrap;
        }

        .content-padding { padding: 25px; }

        .admin-card {
            background-color: var(--white);
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
            padding: 25px;
            margin-bottom: 25px;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }
        .admin-card:hover { transform: translateY(-3px); box-shadow: 0 6px 20px rgba(0,0,0,0.12); }
        .admin-card-header {
            border-bottom: 1px solid var(--light-brown);
            padding-bottom: 15px; margin-bottom: 20px;
            color: var(--dark-brown); font-size: 1.5rem; font-family: 'Playfair Display', serif; font-weight: 700;
        }

        .table-custom {
            border-collapse: separate;
            border-spacing: 0 10px;
            width: 100%;
        }
        .table-custom th {
            background-color: var(--darkest-brown);
            color: var(--white);
            padding: 12px 15px;
            font-weight: 600;
            text-align: left;
            border: none;
        }
        .table-custom td {
            background-color: var(--soft-gray);
            padding: 12px 15px;
            vertical-align: middle;
            border: none;
        }
        .table-custom tbody tr {
            transition: all 0.2s ease;
        }
        .table-custom tbody tr:hover {
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
            transform: translateY(-2px);
            background-color: var(--light-brown);
        }
        .table-custom thead tr th:first-child { border-top-left-radius: 8px; }
        .table-custom thead tr th:last-child { border-top-right-radius: 8px; }
        .table-custom tbody tr:first-child td:first-child { border-top-left-radius: 8px; }
        .table-custom tbody tr:first-child td:last-child { border-top-right-radius: 8px; }
        .table-custom tbody tr:last-child td:first-child { border-bottom-left-radius: 8px; }
        .table-custom tbody tr:last-child td:last-child { border-bottom-right-radius: 8px; }

        .pagination .page-item .page-link {
            border-radius: 5px;
            margin: 0 3px;
            color: var(--dark-brown);
            border-color: var(--medium-brown);
            transition: all 0.2s ease;
        }
        .pagination .page-item .page-link:hover {
            background-color: var(--orange-primary);
            border-color: var(--orange-primary);
            color: white;
        }
        .pagination .page-item.active .page-link {
            background-color: var(--orange-primary);
            border-color: var(--orange-primary);
            color: white;
        }
        .pagination .page-item.disabled .page-link {
            color: #6c757d;
            pointer-events: none;
            background-color: #e9ecef;
            border-color: #dee2e6;
        }
        .form-control-filter {
            border-radius: 8px;
            border: 1px solid var(--medium-brown);
            padding: 8px 12px;
            color: var(--dark-brown);
            background-color: var(--white);
        }
        .form-control-filter:focus {
            border-color: var(--orange-primary);
            box-shadow: 0 0 0 0.25rem rgba(255, 179, 0, 0.25);
        }

        .modal-content {
            border-radius: 10px;
            border: none;
            box-shadow: 0 5px 15px rgba(0,0,0,0.3);
        }
        .modal-header {
            background-color: var(--orange-primary);
            color: var(--darkest-brown);
            border-top-left-radius: 10px;
            border-top-right-radius: 10px;
            border-bottom: none;
        }
        .modal-header .btn-close {
            filter: invert(1);
        }
        .modal-footer {
            border-top: none;
            padding-top: 0;
        }

        @media (max-width: 992px) {
            .sidebar {
                width: 80px;
                min-width: 80px;
            }
            .sidebar-header h3 {
                opacity: 0; width: 0; padding: 0; margin: 0; height: 0;
            }
            .sidebar-menu .list-group-item span {
                opacity: 0; width: 0; display: none;
            }
            .sidebar-menu .list-group-item i {
                margin-right: 0;
            }
            .main-content {
                margin-left: 80px;
                padding-top: 75px;
            }
            .admin-navbar {
                width: calc(100% - 80px);
                left: 80px;
            }
            .sidebar-toggle-btn { display: none; }
        }
        @media (max-width: 768px) {
            .sidebar {
                position: fixed;
                left: -250px;
                box-shadow: none;
                z-index: 1000;
                width: 250px;
                min-width: 250px;
            }
            .sidebar.show {
                left: 0;
                box-shadow: 2px 0 10px rgba(0,0,0,0.2);
            }
            .sidebar.collapsed .sidebar-header h3,
            .sidebar.collapsed .sidebar-menu .list-group-item span {
                opacity: 1;
                width: auto;
                display: inline-block;
            }
            .sidebar.collapsed .sidebar-menu .list-group-item i {
                margin-right: 15px;
            }

            .main-content {
                margin-left: 0;
                width: 100%;
                padding-top: 75px;
            }
            .admin-navbar {
                width: 100%;
                left: 0;
            }
            .sidebar-toggle-btn {
                display: block;
            }
            .admin-panel-title {
                font-size: 1.2rem;
                position: static;
                transform: none;
                flex-grow: 1;
                text-align: center;
            }
            .table-responsive-custom {
                overflow-x: auto;
                -webkit-overflow-scrolling: touch;
            }
            .table-custom {
                width: 100%;
                min-width: 700px;
            }
        }
    </style>
</head>
<body>

     <div class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <h3>Dapur Afdhol Admin</h3>
        </div>
        <ul class="list-group sidebar-menu">
            <a href="{{ route('admin.dashboard') }}" class="list-group-item">
                <i class="fas fa-tachometer-alt"></i> <span>Dashboard</span>
            </a>
            <a href="{{ route('admin.menu.index') }}" class="list-group-item">
                <i class="fas fa-utensils"></i> <span>Manajemen Menu</span>
            </a>
            <a href="#" class="list-group-item">
                <i class="fas fa-clipboard-list"></i> <span>Manajemen Pesanan</span>
            </a>
            <a href="{{ route('admin.users.index') }}" class="list-group-item">
                <i class="fas fa-users"></i> <span>Manajemen Pengguna</span>
            </a>
            <a href="{{ route('admin.reviews.index') }}" class="list-group-item active">
                <i class="fas fa-star"></i> <span>Ulasan Pelanggan</span>
            </a>
            <a href="#" class="list-group-item">
                <i class="fas fa-cogs"></i> <span>Pengaturan Sistem</span>
            </a>
            <hr class="text-white-50">
            <a href="#" class="list-group-item" id="logout-btn">
                <i class="fas fa-sign-out-alt"></i> <span>Logout</span>
            </a>
        </ul>
    </div>

    <div class="main-content" id="main-content">
        <nav class="admin-navbar" id="admin-navbar">
            <button class="toggle-btn" id="sidebar-toggle"><i class="fas fa-bars"></i></button>
            <h4 class="m-0 admin-panel-title">Ulasan Pelanggan</h4>
            <div class="d-flex align-items-center">
                <a href="#" class="nav-link"><i class="fas fa-bell"></i></a>
                <a href="#" class="nav-link"><i class="fas fa-envelope"></i></a>
                <a href="#" class="nav-link"><i class="fas fa-user-circle"></i> Admin</a>
            </div>
        </nav>

        <div class="content-padding">
            <h1 class="mb-4">Ulasan Pelanggan</h1>

            <div class="admin-card">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h5 class="admin-card-header mb-0" style="border-bottom: none;">Daftar Ulasan</h5>
                    <div class="d-flex align-items-center gap-2">
                        <form method="GET" action="{{ route('admin.reviews.index') }}" class="d-flex gap-2">
                            <input type="text" name="search" class="form-control-filter" placeholder="Cari ulasan..." value="{{ request('search') }}" style="width:200px;">
                            <select name="rating" class="form-select form-control-filter" style="width:150px;" onchange="this.form.submit()">
                                <option value="">Semua Rating</option>
                                @for ($i = 5; $i >= 1; $i--)
                                    <option value="{{ $i }}" {{ request('rating') == $i ? 'selected' : '' }}>{{ $i }} Bintang</option>
                                @endfor
                            </select>
                            <select name="menu_id" class="form-select form-control-filter" style="width:200px;" onchange="this.form.submit()">
                                <option value="">Semua Produk</option>
                                @foreach ($menus as $menu)
                                    <option value="{{ $menu->id }}" {{ request('menu_id') == $menu->id ? 'selected' : '' }}>{{ $menu->nama }}</option>
                                @endforeach
                            </select>
                            <button type="submit" class="btn btn-primary-custom">Filter</button>
                        </form>
                    </div>
                </div>

                <div class="table-responsive-custom">
                    <table class="table table-borderless table-custom">
                        <thead>
                            <tr>
                                <th>Produk</th>
                                <th>Pengguna</th>
                                <th class="text-center">Rating</th>
                                <th class="text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse ($reviews as $review)
                                <tr>
                                    <td>
                                        <div class="product-info">
                                            @if($review->menu && $review->menu->gambar)
                                                <img src="{{ asset('storage/'.$review->menu->gambar) }}" alt="{{ $review->menu->nama }}">
                                            @else
                                                <img src="https://via.placeholder.com/50?text=No+Image" alt="No Image">
                                            @endif
                                            <span>{{ $review->menu->nama ?? 'Produk tidak ditemukan' }}</span>
                                        </div>
                                    </td>
                                    <td>{{ $review->user->name ?? 'User Tidak Diketahui' }}</td>
                                    <td class="text-center">
                                        <div class="star-rating">
                                            @for ($i = 1; $i <= 5; $i++)
                                                <i class="fa-star {{ $i <= $review->rating ? 'fas' : 'far' }}"></i>
                                            @endfor
                                        </div>
                                    </td>
                                    <td class="text-center">
                                        <a href="{{ route('admin.reviews.show', $review->id) }}" class="btn btn-sm btn-primary-custom"><i class="fas fa-eye"></i> Lihat</a>
                                    </td>
                                </tr>
                            @empty
                                <tr>
                                    <td colspan="4" class="text-center py-4">Tidak ada ulasan ditemukan.</td>
                                </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>

                <div class="d-flex justify-content-center mt-3">
                    {{ $reviews->withQueryString()->links('pagination::bootstrap-5') }}
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Sidebar toggle sama persis kayak script yang kamu kasih
    </script>
</body>
</html>
