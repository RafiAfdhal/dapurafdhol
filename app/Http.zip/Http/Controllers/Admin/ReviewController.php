<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Review;
use App\Models\Menu; // tambahkan ini

class ReviewController extends Controller
{
    // Tampilkan semua review
    public function index()
    {
        // Ambil semua review + relasi user & menu
        $reviews = Review::with(['user', 'menu'])->latest()->paginate(10);

        // Ambil semua menu untuk filter dropdown
        $menus = Menu::all();

        return view('admin.reviews.index', compact('reviews', 'menus'));
    }

    // Tampilkan detail review
    public function show($id)
    {
        $review = Review::with(['user', 'menu'])->findOrFail($id);

        return view('admin.reviews.show', compact('review'));
    }
}
