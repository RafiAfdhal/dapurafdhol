<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rule;

class UserController extends Controller
{
    /**
     * Tampilkan daftar semua pengguna dengan filter dan paginasi.
     */
    public function index(Request $request)
    {
        // Mendefinisikan peran-peran (roles) yang tersedia
        $roles = ['admin', 'pelanggan', 'kurir'];

        // Memulai query untuk model User
        $users = User::query()
            // Filter berdasarkan pencarian nama atau email
            ->when($request->filled('search'), function ($query) use ($request) {
                $search = $request->input('search');
                return $query->where('name', 'like', "%{$search}%")
                    ->orWhere('email', 'like', "%{$search}%");
            })
            // Filter berdasarkan peran (role)
            ->when($request->filled('role'), function ($query) use ($request) {
                return $query->where('role', $request->input('role'));
            })
            // Mengurutkan hasil dari yang terbaru
            ->latest()
            // Menerapkan paginasi dengan 10 item per halaman
            ->paginate(10);

        // Mengirim data pengguna dan peran ke view 'admin.users.index'
        return view('admin.users.index', compact('users', 'roles'));
    }

    /**
     * Tampilkan formulir untuk membuat pengguna baru.
     * Metode ini sebelumnya hilang dan telah ditambahkan kembali.
     */
    public function create()
    {
        $roles = ['admin', 'pelanggan', 'kurir'];
        return view('admin.users.create', compact('roles'));
    }


    /**
     * Simpan pengguna baru ke database.
     */
    public function store(Request $request)
    {
        // Validasi data yang masuk dari request
        $validatedData = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'role' => ['required', 'string', Rule::in(['admin', 'pelanggan', 'kurir'])],
            'password' => ['required', 'string', 'min:8'],
        ]);

        // Mengenkripsi (hash) kata sandi sebelum disimpan
        $validatedData['password'] = Hash::make($validatedData['password']);

        // Membuat record pengguna baru di database
        User::create($validatedData);

        // Mengarahkan kembali ke halaman index dengan pesan sukses
        return redirect()->route('admin.users.index')
            ->with('success', 'Pengguna berhasil ditambahkan.');
    }

    /**
     * Tampilkan formulir untuk mengedit pengguna yang ada.
     */
    public function edit(User $user)
    {
        $roles = ['admin', 'pelanggan', 'kurir'];
        return view('admin.users.edit', compact('user', 'roles'));
    }

    /**
     * Perbarui data pengguna di database.
     */
    public function update(Request $request, User $user)
    {
        // Validasi data, dengan aturan 'unique' yang mengabaikan pengguna yang sedang diedit
        $validatedData = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', Rule::unique('users')->ignore($user->id)],
            'role' => ['required', 'string', Rule::in(['admin', 'pelanggan', 'kurir'])],
            'password' => ['nullable', 'string', 'min:8'],
        ]);

        // Jika password diisi, enkripsi password baru
        if ($request->filled('password')) {
            $validatedData['password'] = Hash::make($validatedData['password']);
        } else {
            // Jika tidak, hapus kunci 'password' agar password lama tidak diubah
            unset($validatedData['password']);
        }

        // Perbarui record pengguna di database
        $user->update($validatedData);

        // Mengarahkan kembali ke halaman index dengan pesan sukses
        return redirect()->route('admin.users.index')
            ->with('success', 'Pengguna berhasil diperbarui.');
    }

    /**
     * Hapus pengguna dari database.
     */
    public function destroy(User $user)
    {
        // Menghapus record pengguna dari database
        $user->delete();

        // Mengarahkan kembali ke halaman index dengan pesan sukses
        return redirect()->route('admin.users.index')
            ->with('success', 'Pengguna berhasil dihapus.');
    }
}
