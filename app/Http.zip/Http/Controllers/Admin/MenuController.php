<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Menu;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class MenuController extends Controller
{
    public function index(Request $request)
    {
        $kategori = ['Sarapan', 'Makan Siang', 'Makan Malam', 'Cemilan', 'Dessert', 'Minuman'];
        $status_options = ['Tersedia', 'Tidak Tersedia'];
        
        $menus = Menu::query()
            ->when($request->filled('kategori'), function ($query) use ($request) {
                return $query->where('kategori', $request->kategori);
            })
            ->when($request->filled('status'), function ($query) use ($request) {
                return $query->where('status', $request->status);
            })
            ->latest()
            ->paginate(10);
            
        return view('admin.menu.index', compact('menus', 'kategori', 'status_options'));
    }

    public function create()
    {
        $kategori = ['Sarapan', 'Makan Siang', 'Makan Malam', 'Cemilan', 'Dessert', 'Minuman'];
        return view('admin.menu.create', compact('kategori'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'nama' => 'required|string|max:255',
            'kategori' => 'required',
            'deskripsi' => 'nullable|string',
            'harga' => 'required|numeric|min:0',
            'stok' => 'required|integer|min:0',
            'gambar' => 'nullable|image|mimes:jpg,jpeg,png|max:2048',
            'status' => 'required|in:Tersedia,Tidak Tersedia'
        ]);

        $path = $request->file('gambar')?->store('menus', 'public');

        Menu::create([
            'nama' => $request->nama,
            'kategori' => $request->kategori,
            'deskripsi' => $request->deskripsi,
            'harga' => $request->harga,
            'stok' => $request->stok,
            'gambar' => $path,
            'status' => $request->status
        ]);

        return redirect()->route('admin.menu.index')->with('success', 'Menu berhasil ditambahkan.');
    }
    
    public function edit(Menu $menu)
    {
        $kategori = ['Sarapan', 'Makan Siang', 'Makan Malam', 'Cemilan', 'Dessert', 'Minuman'];
        return view('admin.menu.edit', compact('menu', 'kategori'));
    }
 
    public function update(Request $request, Menu $menu)
    {
        $request->validate([
            'nama' => 'required|string|max:255',
            'kategori' => 'required',
            'deskripsi' => 'nullable|string',
            'harga' => 'required|numeric|min:0',
            'stok' => 'required|integer|min:0',
            'gambar' => 'nullable|image|mimes:jpg,jpeg,png|max:2048',
            'status' => 'required|in:Tersedia,Tidak Tersedia'
        ]);
 
        if ($request->hasFile('gambar')) {
            if ($menu->gambar) {
                Storage::disk('public')->delete($menu->gambar);
            }
            $menu->gambar = $request->file('gambar')->store('menus', 'public');
        }
 
        $menu->update($request->only(['nama','kategori','deskripsi','harga','stok','status','gambar']));
 
        return redirect()->route('admin.menu.index')->with('success', 'Menu berhasil diperbarui.');
    }
 
    public function destroy(Menu $menu)
    {
        if ($menu->gambar) {
            Storage::disk('public')->delete($menu->gambar);
        }
        $menu->delete();
        return redirect()->route('admin.menu.index')->with('success', 'Menu berhasil dihapus.');
    }
}